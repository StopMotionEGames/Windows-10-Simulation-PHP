<body>
  <div class="bsod0"><a href="/"></a></div>
  <div class="bsod1">
    <p>
      Você parou uma página rara no nosso servidor e pode voltar para a anterior. Essa página está sendo mostrada por algum motivo.
    </p>
  </div>
  <div class="bsod2">Nada para coletar</div>
  <div class="bsod3">
    <img src="/ResponseCodes/imgs/questionMark.png" alt="Unseted QR Code (Nothing) :(">
    <div class="bsod4">
      <div class="bsod7">
        Nosso servidor detectou um erro que não está definido na nossa lista. Ainda!
      </div>
      <div class="bsod5">
        Você pode ter digitado o link de forma errada, ou ele está quebrado.
      </div>
      <div class="bsod6">
        <p>O que falhou: <?php echo $requestedUrl ?><br></p>
        <br>
        Código de parada: <?php echo $stopCode ?>
      </div>
    </div>
  </div>
</body>