<body>
  <div class="bsod0"><a href="/"></a></div>
  <div class="bsod1">
    <p>
      Nosso servidor está com problemas e você poderá voltar mais tarde. Estamos tentando resolver o problema.
    </p>
  </div>
  <div class="bsod2">Nada para coletar</div>
  <div class="bsod3">
    <img src="/ResponseCodes/imgs/500.png" alt="">
    <div class="bsod4">
      <div class="bsod7">
        Isso pode ter ocorrido devido a erros internos no servidor.
      </div>
      <div class="bsod5">
        Apenas espere até que o problema seja concertado
      </div>
      <div class="bsod6">
        O que falhou: server<br>
        <br>
        Código de para: <?php echo $stopCode ?>
      </div>
    </div>
  </div>
</body>