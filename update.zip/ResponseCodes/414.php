<body>
  <div class="bsod0"><a href="/"></a></div>
  <div class="bsod1">
    <p>
      Você acabou cainda em uma página muito específique e pode voltar para a página anterior.
    </p>
  </div>
  <div class="bsod2">Nada para coletar</div>
  <div class="bsod3">
    <img src="/ResponseCodes/imgs/414.png" alt="">
    <div class="bsod4">
      <div class="bsod7">
        Nosso servidor detectou que você tentou acessar uma página cuja a URL excedeu o limite para esse servidor.
      </div>
      <div class="bsod5">
        Você pode tentar acessar outra página ou desistir dessa.
      </div>
      <div class="bsod6">
        O que falhou: Typed-URI<br>
        <br>
        Código de parada: <?php echo $stopCode ?>
      </div>
    </div>
  </div>
</body>