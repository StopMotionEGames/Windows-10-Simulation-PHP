<body>
  <div class="bsod0"><a href="/"></a></div>
  <div class="bsod1">
    <p>
      O acesso a essa página foi negado. Você não deveria estar acessando aqui sem permissões avançadas.
    </p>
  </div>
  <div class="bsod2">Nada para coletar</div>
  <div class="bsod3">
    <img src="/ResponseCodes/imgs/403.png" alt="">
    <div class="bsod4">
      <div class="bsod7">
        Nosso servidor detectou que você está tentando acessar uma página que você não tem acesso.
      </div>
      <div class="bsod5">
        Sugerimos que você volte para a página anterior ao invés de ficar olhando para essa <i>BSOD</i>.
      </div>
      <div class="bsod6">
        <p>O que falhou: Acess_Previlegies<br></p>
        <br>
        Código de parada: <?php echo $stopCode ?>
      </div>
    </div>
  </div>
</body>