
<body>
    <div class="bsod0"><a href="/" id=":)"></a></div>
    <div class="bsod1">
      <p>
        Você acessou corretamente nessa página e sem problemas de acesso.
      </p>
    </div>
    <div class="bsod2">Nada para coletar</div>
    <div class="bsod3">
      <img src="/ResponseCodes/imgs/200.png" alt="">
      <div class="bsod4">
        <div class="bsod7">
          Nosso servidor detectou que você entrou corretamente em uma página de erro.
        </div>
        <div class="bsod5">
          <?php echo $reponseCode ?> quer dizer que a página foi encontrada e sem nenhum imprevisto.
        </div>
        <div class="bsod6">
          O que falhou: nada<br>
          <br>
          Código de resposta: <?php echo $stopCode ?>
        </div>
      </div>
    </div>
  </body>