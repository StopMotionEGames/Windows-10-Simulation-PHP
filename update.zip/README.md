Por enquanto isso ainda é apenas um teste. O [./README.md] ainda reberá mudanças.

Esse projeto requer uma configuração com servidor Apache com PHP (Com certificado OpenSSL de preferência) e MySQL
