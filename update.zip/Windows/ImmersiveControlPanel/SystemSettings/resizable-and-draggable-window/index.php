<link rel="stylesheet" href="/css/style.css">
<link rel="stylesheet" href="/css/window.css">
<script defer src="/js/window.js"></script>
<div class="window">
  <div class="resizer corner tl"></div>
  <div class="resizer corner tr"></div>
  <div class="resizer corner bl"></div>
  <div class="resizer corner br"></div>
  <div class="resizer t"></div>
  <div class="resizer b"></div>
  <div class="resizer l"></div>
  <div class="resizer r"></div>

  <div class="body">
    <div class="topbar">
      <div class="wtitle">Window</div>
      <div class="btns">
        <div class="wminimize">&minus;</div>
        <div class="wmaximize">&square;</div>
        <div class="wclose">&times;</div>
      </div>
    </div>
    <div class="wcontent">
      <div class="section">
        <div class="sectiontitle">BETA :)</div>
        <p>Essa é uma janela redimensinável e arrastável! Isso ser uma beta disso! Aqui você pode colocar qualuqer
          coisas (Dentro de div.wcontent)</p>
        <input type="text" placeholder="Texto (para nada)">
      </div>
    </div>
  </div>
</div>